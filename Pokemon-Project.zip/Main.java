import java.util.concurrent.atomic.DoubleAdder;
import java.util.Scanner; 
import java.util.Arrays;

public class Main{
  private static String[] types = {"Normal", "Fire", "Fighting", "Water", "Flying", "Grass", "Poison", "Electric", "Ground", "Psychic", "Rock", "Ice", "Bug", "Dragon", "Ghost", "Dark", "Steel", "Fairy"};
  private static String compType = "Fire";
  private static String userType;
  private static int hP;
  private static int comphP;

  // void return, so will print messages
  public static void main(String[] args) {
    hP = 100;
    comphP = 100;
    int roundNum = 1;
    int compRandom;
    Scanner myObj = new Scanner(System.in);
    System.out.println("Choose a Pokemon type from the following:");
    System.out.println(Arrays.asList(types));
    int numEquals = 0;
    
    while (numEquals == 0){
      userType = myObj.nextLine();
      for (int i = 0; i<types.length; i++){
        if (userType.equalsIgnoreCase(types[i]))
          numEquals++;
    }
      if (numEquals == 0)
        System.out.println("Please choose a type above");
    }

    System.out.println("Your Pokemon is " + userType + " type");
    System.out.println("The opponent's Pokemon is " + compType + " type");
    System.out.println();
    System.out.println("Fight = RANDOM, Heal = +10!");

    Scanner chooseMove = new Scanner(System.in);

    while (!dead()){
      System.out.println();
      System.out.println("Round " + roundNum);
      System.out.println("Your turn! Choose to Fight or Heal!");
      String choice = chooseMove.nextLine();
      if (choice.equals("Fight") || choice.equals("fight")){
        userFight();
        System.out.println("The opponent now has " + getComphP() + " hP! You now have " + gethP() + " hP!");
      }
      else if (choice.equals("Heal") || choice.equals("heal")) {
        userHeal();
        System.out.println("The opponent now has " + getComphP() + " hP! You now have " + gethP() + " hP!");
      }
      else
           System.out.println("Please choose to fight or heal");
    
      System.out.println("Opponent's turn!");
      compRandom = (int)(Math.random()*2)+1;
      if (compRandom ==2 && comphP <= 100) {
        compHeal();
        System.out.println("The opponent healed!");
        System.out.println("The opponent now has " + getComphP() + " hP! You now have " + gethP() + " hP!");
      }
      else {
        compFight();
        System.out.println("The opponent now has " + getComphP() + " hP! You now have " + gethP() + " hP!");
      }
      roundNum++;
    }
    if (comphP <= 0)
      System.out.println("YOU WIN!!! CELEBRATE!!! THAT'S LIT!");
    else if (hP <= 0)
      System.out.println("You lost...C'mon man...");
  }

  // boolean return value, either true or false, meaning super effective or not
  public static boolean userEffectiveTypes(String userType) {
    for (int i = 0; i<types.length; i++){
      if (types[i].equals(userType) && userType.equals(types[8]))
        return true;
      else if (types[i].equals(userType) && userType.equals(types[10]))
        return true;
      else if (types[i].equals(userType) && userType.equals(types[3]))
        return true;
    }
    return false;
  } 

// similar to userEffectiveTypes, except determines whether opponent's attacks are super effective or not
public static boolean compEffectiveTypes(String userType) {
  if (userType.equals(types[12]) || userType.equals(types[5]) || userType.equals(types[16]) || userType.equals(types[11]))
    return true;
  else
    return false;
  } 

// void method, deducts random amount of hP from opponent
 public static void userFight(){
    if (userEffectiveTypes(userType)) {
      int compDiffFight = (int)(Math.random()*21 + 30);
      comphP -= compDiffFight;
      System.out.println("You attacked. Super Effective! The opponent lost " + compDiffFight + " hP!");
    }
    else {
      int nonEffCompFight = (int)(Math.random()*16 + 15);
      comphP -= nonEffCompFight;
      System.out.println("You attacked. The opponent lost " + nonEffCompFight + " hP!");
    }
  }

// same as userFight, but deducts random amount of hP from user
  public static void compFight(){
    if (compEffectiveTypes(userType)) {
      int effDiffFight = (int)(Math.random()*21 + 30);
      hP -= effDiffFight;
      System.out.println("The opponent attacked. Super Effective! You lost " + effDiffFight + " hP...");
    }
    else {
      int nonEffDiffFight = (int)(Math.random()*16 + +15);
      hP -= nonEffDiffFight;
      System.out.println("The opponent attacked. You lost  " + nonEffDiffFight + " hP...");
    }
  }

// opponent's hP increases
  public static void compHeal() {
    comphP += 10;
    System.out.println("The opponent healed! +10 hP!");
  }

// user's hP increases
  public static void userHeal() {
    hP += 10;
    System.out.println("You healed! +10 hP!");
  }

// method to retrieve current hP of user
  public static int gethP() {
    if (hP >100)
      hP = Math.min(100, hP);
    else if (hP < 0)
      hP = Math.max(0, hP);
    return hP;
  }

// method to retrieve current hP of opponent
  public static int getComphP() {
    if (comphP >100)
      comphP = Math.min(100, comphP);
    else if (comphP < 0)
      comphP = Math.max(0, comphP);
    return comphP;
  }

// boolean method to determine whether one Pokemon has died or not (doesn't return which Pokemon has died though)
  public static boolean dead() {
    if (comphP <= 0 || hP <=0)
      return true;
    else 
      return false;
  }
}