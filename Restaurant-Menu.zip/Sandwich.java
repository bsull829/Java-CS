public class Sandwich extends SubwayFood{
  private boolean veg;
  private double sprice;
  private int num;
  private String item;

  public Sandwich(){
    sprice = 6.40;
    num = super.getQuantity();
    item = "Sandwich ";
    veg = false;
  }

  public Sandwich(int q, boolean a){
    super(q);
    sprice = 6.40;
    veg = a;
    num = super.getQuantity();
    if (veg)
      item = "Veggie Sandwich";
    else 
      item = "Sandwich";
  }

  public void assemble(){
    if (veg){
      sprice -= 1.20;
    }
    if (flatbread()){
      sprice += 0.70;
    }
  }

  public void isYummy(){
    System.out.println("This sandwich is so good!");
  }

  public double cost(){
    return sprice;
  }

  public void getPrice(){
    System.out.println("Your total cost is " + (sprice*super.getQuantity()) + " SGD. ");
  }

  public boolean flatbread(){
    if (num == 0)
      return false;
    else if (veg && num !=0){
      System.out.println("You have selected flatbread.");
      return true;
    }
    else
      return false;
  }

  public String toString(){
    return super.toString() + item;
  }

  public boolean equals(Object other){
    Sandwich otherObj = (Sandwich) other;
    return super.equals(otherObj) && this.item.equals(otherObj.item);
  }
}