public class Cookie extends SubwayFood{
  private double cprice;
  private int quantity;
  private String item;

  public Cookie(){
    cprice = 1.30;
    quantity = 0;
    item = "cookie ";
  }

  public Cookie(int a){
    super(a);
    cprice = 1.30;
    quantity = super.getQuantity();
    item = "cookie ";
  }

  public void isYummy(){
    System.out.println("This cookie is so good!");
  }

  public void getPrice(){
    System.out.println("Your total cost is " + (cprice*super.getQuantity()) + " SGD. ");
  }

  public String toString(){
    return super.toString() + item;
  }

  public boolean equals(Object other){
    Cookie otherObj = (Cookie) other;
    return super.equals(otherObj) && this.item.equals(otherObj.item);
  }
}