import java.util.ArrayList;

class Main {
  public static void main(String[] args) {
    ArrayList<SubwayFood> order = new ArrayList<SubwayFood>();

    order.add(new SubwayFood());
    order.add(new Sandwich());
    order.add(new Cookie());
    order.add(new MeatballMarinara());
    order.add(new Sandwich(1, true));
    order.add(new MeatballMarinara(2));
    order.add(new MeatballMarinara(2));
    order.add(new Cookie(2));
    order.add(new SubwayFood(4));
    order.add(new Sandwich(2, false));

  order.get(6).isYummy();
 ((Sandwich)order.get(1)).isYummy();
 ((SubwayFood)order.get(1)).isYummy();
 //((Sandwich)order.get(0)).isYummy();
order.get(1).customerService();
//auto upcasting

//order.get(4).flatbread();
 ((Sandwich)order.get(4)).flatbread();
// model casting and no casting

  System.out.println(order.get(2).toString());
  System.out.println(order.get(8).getQuantity());
  System.out.println(order.get(2).getQuantity());
  System.out.println(order.get(8).equals(order.get(8)));
  System.out.println(order.get(4).equals(order.get(9)));

  ((Sandwich)order.get(6)).assemble();
  ((MeatballMarinara)order.get(6)).getPrice();

  ((Sandwich)order.get(4)).assemble();
  ((Sandwich)order.get(4)).getPrice();

  ((MeatballMarinara)order.get(5)).heatUp(0);

  //((Sandwich)order.get(8)).assemble();
      }
}