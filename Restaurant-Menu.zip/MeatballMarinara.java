public class MeatballMarinara extends Sandwich{
  private String name = "Meatball Marinara";
  private int timeSpent = 0;
  private int heatLevel = 0;
  private double mprice; 
  
  public MeatballMarinara(){
    mprice = super.cost();
    name = "Meatball Marinara";
  }
  
  public MeatballMarinara(int a){
    super(a, false);
    mprice = super.cost();
    name = "Meatball Marinara";
  }

  public void heatUp(int heatLevel){
    heatLevel += (int)(Math.random()*40)+30;
    if (heatLevel > 35){
      meltCheese();
      timeSpent+=15;
      System.out.println("Your sub has been toasted in  " + timeSpent + " seconds!");
    }
    else if (heatLevel > 60){
      System.out.println("Whoops...Your sub was (accidentally) burned. Here, we'll try again in a minute.");
      timeSpent+=60;
      heatLevel = 0; 
      heatUp(heatLevel);
    }
    else {
      System.out.println("Oh...it seems like the machine isn't working.Let's try again!");
      timeSpent+=15;
      heatUp(heatLevel);
    }
  }

    /* iteration comparison
    for (int i = heatLevel; i<=70; i+= (int)(Math.random()*40)+30){
      if (i > 60){
        System.out.println("Whoops...Your sub was (accidentally) burned. Here, we'll try again in a minute.");
        timeSpent+=60;
        i = 0;
      }
      else if (i < 35){
        System.out.println("Oh...it seems like the machine isn't working.Let's try again!");
        timeSpent+=15;
      }
      else{
        meltCheese();
        System.out.println("Your sub has been toasted in  " + timeSpent + " seconds!");
      }
    }
  */

  public void meltCheese(){
    System.out.println("Sizzle....sizzle...CHEESE TOASTED!");
  }

  public void isYummy(){
    System.out.println("This Meatball Marinara is so good!");
  }

  public void getPrice(){
    System.out.println("Your Meatball Marinara is " + (mprice*getQuantity()) + " SGD!");
  }

  public String toString(){
    return super.toString() + name;
  }

  public boolean equals(Object other){
    MeatballMarinara otherObj = (MeatballMarinara) other;
    return super.equals(otherObj) && (this.heatLevel == otherObj.heatLevel);
  }
}