public class SubwayFood{
  private int quantity;
  private String brand = "Subway ";

  public SubwayFood(int a){
    quantity = a;
  }
  
  public SubwayFood(){
    quantity = 0;
  }
  
  public void customerService(){
    System.out.println("Welcome to Subway! What would you like to order?");
  }

  public int getQuantity(){
    return quantity;
  }

  public void isYummy(){
    System.out.println(brand +  " is so good!");
  }

  public void stupidQuestion(){
    System.out.println("Where's the closest subway?");
    System.out.println("-_-");
  }

  public boolean equals(Object other){
    SubwayFood otherObj = (SubwayFood) other;
    return (this.quantity == otherObj.quantity);
  }

  public String toString(){
    return brand;
  }
}
