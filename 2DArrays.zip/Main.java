import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Subway a = new Subway();

    a.printMap();
    System.out.println();

    System.out.println("Your starting destination is Station " + a.currLine()+"-"+ a.currStationNum()+".");
    System.out.println("Each station is 4 mins away. It takes 2 mins to go to another line through an intersection");
    System.out.println();
    a.printIntersections();

    System.out.println();
    Scanner myObj = new Scanner(System.in);
    System.out.println("Choose destination: Which line is your destination (1,2,or 3)");

    int destLine = myObj.nextInt()-1;

    System.out.println();
    Scanner myObj2 = new Scanner(System.in);
    System.out.println("Choose destination: Which station number is your destination");

    int destNum = myObj2.nextInt();

    a.setDestination(destLine,destNum);

    a.shortestPath();
  }
}