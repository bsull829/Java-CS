public class Station{
  private int line;
  private int stationNum;
  private int frontDistance;
  private int backDistance;
  
  public Station(){
    line = 0;
    stationNum = 0;
    frontDistance = 0;
    backDistance = 0;
  }

  public void setStation(int a, int b){
    line = a;
    stationNum = b;
    if (b<getLineLength())
      frontDistance = 4;
    if (b!= 1)
      backDistance = 4;
  }

  public int getLine(){
    return line;
  }

  public int getLineLength(){
    if (line == 1)
      return 7;
    if (line == 2)
      return 8;
    if (line == 3)
      return 9;
    else 
      return 0;
  }

  public int getStationNum(){
    return stationNum;
  }

  public int getFrontDistance(){
    return frontDistance;
  }

  public int getBackDistance(){
    return backDistance;
  }

  public int getIntersectionDist(){
    return 2;
  }
 
  public boolean isIntersection(){
    if (line == 1 && stationNum ==5)
      return true;
    if (line == 2 && stationNum == 2)
      return true;
    if (line == 3 && stationNum == 0)
      return true;
    return false;
  }
}