import java.util.Scanner; 

public class Subway{
  private Station currStation;
  private Station[][] subwayStation;
  private int currNum;
  private int currLine;
  private int finNum;
  private int finLine;
  private int sumDist;

  public Subway(){
    Station[][] newArray = new Station[3][];
    newArray[0] = new Station[7];
    for (int i = 0; i<newArray[0].length; i++){
        newArray[0][i] = new Station();
        newArray[0][i].setStation(1,i);
      }

    newArray[1] = new Station[8];
    for (int i = 0; i<newArray[1].length; i++){
      newArray[1][i] = new Station();
      newArray[1][i].setStation(2,i);
    }

    newArray[2] = new Station[9];
    for (int i = 0; i<newArray[2].length; i++){
      newArray[2][i] = new Station();
      newArray[2][i].setStation(3,i);
    }
    
    sumDist = 0;
    subwayStation = newArray;
    currLine = 0;
    currNum = (int)(Math.random()*newArray[0].length+1);
    currStation = subwayStation[currLine][currNum];
  }

  public void printMap(){
    for (int i = 0;i<subwayStation.length;i++){
      for (int j = 0; j<subwayStation[i].length;j++){
        System.out.print("  " + (i+1) + "-" + j);
      }
      System.out.println();
    }
  }

  public int currStationNum(){
    return currNum;
  }

  public int currLine(){
    return currLine+1;
  }

  public void setDestination(int a, int b){
    finNum = b;
    finLine = a;
  }

  public void nextIntersection(){
    if (currLine<3){
      currLine++;
      currStation = subwayStation[currLine][currNum];
      sumDist+= 2;
    }
  }
  
  public void nextStation(){
    if (currLine == 0){
      if (currNum<5){
        currNum++;
        currStation = subwayStation[currLine][currNum];
        sumDist+=4;
      }
      if (currLine>5){
        currNum++;
        currStation = subwayStation[currLine][currNum];
        sumDist+=4;
      }
    }

    else if (currLine == 1){
      if (currNum<2){
        currNum++;
        currStation = subwayStation[currLine][currNum];
        sumDist+=4;
      }
      if (currNum>2){
        currNum--;
        currStation = subwayStation[currLine][currNum];
        sumDist+=4;
      }
    }
  }

  public void sameLine(){
    if (finNum>currNum){
      currNum++;
      currStation = subwayStation[currLine][currNum];
      sumDist+=4;
      }
    if (finNum<currNum){
      currNum--;
      currStation = subwayStation[currLine][currNum];
      sumDist+=4;
    }
  }
  
  public void printIntersections(){
    for (int i = 0;i<subwayStation.length;i++){
      for (int j = 0; j<subwayStation[i].length;j++){
        if (subwayStation[i][j].isIntersection())
          System.out.println("  " + (i+1) + "-" + j + " is an intersection.");
      }
    }
  }

  public void shortestPath(){
    System.out.println();
    while (currLine != finLine){
      if (currStation.isIntersection()){
        nextIntersection();
        System.out.print((currLine+1)+"-"+ currNum + " --> ");
      }
      else {
        nextStation();
        System.out.print((currLine+1)+"-"+ currNum + " --> ");
      }
    }

    while (currNum != finNum && currLine == finLine){
      System.out.print((currLine+1)+"-"+ currNum + " --> ");
      sameLine();
    }

    System.out.print((currLine+1)+"-"+ currNum);
    System.out.println();
    System.out.println("To get to your destination, it will take " + sumDist + " mins!");
    System.out.println("Safe travels!");
  }
}